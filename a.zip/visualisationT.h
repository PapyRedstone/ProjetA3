#include <unistd.h>
#include "define.h" 

void visualisationT(temp_t myTemp);
