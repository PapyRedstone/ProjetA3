#include "regulation.h"
	 
float regulationTest(int regul,float csgn,float* tabT, int nT){
  float cmd = 100.;
  int i;
  
  if(regul == 1){
    cmd = ToR(csgn, tabT[nT-1]);
  }else if(regul == 2){
    PID_param p = {1,0.1,0.1, 10, 0, 0, 0};
    for(i=0; i<nT; i++){
      cmd = PID(csgn, tabT[i], &p, 1);
    }
    //cmd = PID(csgn, tabT[nT-1], tabT[nT-1]);
  }
  
  return cmd;
}

float ToR(float csgn, float Tint){
  if(csgn > Tint){
    return 40.0;
  }
  return 0.0;
}

float PID(float csgn, float Tint, PID_param *param, int mode){
  float result;
  switch(mode){
  case 1:{//test
    static float integral = 0;
    float P,I,D, error, derivated;

    error = csgn - Tint;
    //integral += error * param->dt + (error - param->lasterror)/2 * param->dt;
    derivated = (error - param->lasterror) / param->t;
    
    P = param->Kp * error;
    if(param->t){
      integral += (error + param->lasterror)/2 *param->dt;
      I = param->Ki * integral;
      D = param->Kd * derivated;
    }else{
      I =0;
      D = 0;
    }
    
    
    result = P+I+D;

    printf("csgn = %f, result = %f, P = %f, I = %f, D = %f\n", csgn, result, P, I, D);
    
    if(result > 100){
      //sum_error1 -= error * param->dt;
      result = 100;
    }else if(result < 0){
      //sum_error1 -= error * param->dt;
      result = 0;
    }

    param->lasterror = error;
    param->lastTint = Tint;
    param->t += param->dt;
    
    break;
  }
  case 2:{//integration
    static float sum_error = 0;
    
    float P,I,D, error, last_error;

    //compute errors
    error = csgn - Tint;
    sum_error += error * param->dt;
    
    P = param->Kp * error;
    I = param->Ki * sum_error;
    D = param->Kd * (error - param->lasterror) / param->dt;
    
    result = P+I+D;
    
    if(result > 100){
      sum_error -= error * param->dt;
      return 100;
    }else if(result < 0){
      sum_error -= error * param->dt;
      return 0;
    }

    param->lasterror = error;

    break;
  }
  default:
    result = 0;
  }

  return result;
}
