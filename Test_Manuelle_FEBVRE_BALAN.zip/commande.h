#include "define.h"
#include <windows.h>
#include <math.h>
#include "ftd2xx.h"

void commande(FT_HANDLE ftHandle, float cmd);