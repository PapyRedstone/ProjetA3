#include "define.h"
#include <windows.h>
#include <math.h>
#include "ftd2xx.h"

FT_HANDLE initUSB();
temp_t releve(FT_HANDLE ftHandle);